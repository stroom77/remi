<?php
$verbose = FALSE; // Set to TRUE if you don't want to display invalid code coupons
$prefix = array(
	[
		"LG2", // set prefix
		5 // random digits are used after prefix (e.g: LG2_____)
	],
	// [
	// 	"COY",
	// 	5 
	// ]
);